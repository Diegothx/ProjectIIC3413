// Generated from /home/dish/github/ProjectIIC3413/src/query/parser/grammar/IIC3413DBParser.g4 by ANTLR 4.13.1
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link IIC3413DBParser}.
 */
public interface IIC3413DBParserListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link IIC3413DBParser#root}.
	 * @param ctx the parse tree
	 */
	void enterRoot(IIC3413DBParser.RootContext ctx);
	/**
	 * Exit a parse tree produced by {@link IIC3413DBParser#root}.
	 * @param ctx the parse tree
	 */
	void exitRoot(IIC3413DBParser.RootContext ctx);
	/**
	 * Enter a parse tree produced by {@link IIC3413DBParser#query}.
	 * @param ctx the parse tree
	 */
	void enterQuery(IIC3413DBParser.QueryContext ctx);
	/**
	 * Exit a parse tree produced by {@link IIC3413DBParser#query}.
	 * @param ctx the parse tree
	 */
	void exitQuery(IIC3413DBParser.QueryContext ctx);
	/**
	 * Enter a parse tree produced by {@link IIC3413DBParser#createQuery}.
	 * @param ctx the parse tree
	 */
	void enterCreateQuery(IIC3413DBParser.CreateQueryContext ctx);
	/**
	 * Exit a parse tree produced by {@link IIC3413DBParser#createQuery}.
	 * @param ctx the parse tree
	 */
	void exitCreateQuery(IIC3413DBParser.CreateQueryContext ctx);
	/**
	 * Enter a parse tree produced by {@link IIC3413DBParser#insertQuery}.
	 * @param ctx the parse tree
	 */
	void enterInsertQuery(IIC3413DBParser.InsertQueryContext ctx);
	/**
	 * Exit a parse tree produced by {@link IIC3413DBParser#insertQuery}.
	 * @param ctx the parse tree
	 */
	void exitInsertQuery(IIC3413DBParser.InsertQueryContext ctx);
	/**
	 * Enter a parse tree produced by {@link IIC3413DBParser#selectQuery}.
	 * @param ctx the parse tree
	 */
	void enterSelectQuery(IIC3413DBParser.SelectQueryContext ctx);
	/**
	 * Exit a parse tree produced by {@link IIC3413DBParser#selectQuery}.
	 * @param ctx the parse tree
	 */
	void exitSelectQuery(IIC3413DBParser.SelectQueryContext ctx);
	/**
	 * Enter a parse tree produced by {@link IIC3413DBParser#schema}.
	 * @param ctx the parse tree
	 */
	void enterSchema(IIC3413DBParser.SchemaContext ctx);
	/**
	 * Exit a parse tree produced by {@link IIC3413DBParser#schema}.
	 * @param ctx the parse tree
	 */
	void exitSchema(IIC3413DBParser.SchemaContext ctx);
	/**
	 * Enter a parse tree produced by {@link IIC3413DBParser#datatype}.
	 * @param ctx the parse tree
	 */
	void enterDatatype(IIC3413DBParser.DatatypeContext ctx);
	/**
	 * Exit a parse tree produced by {@link IIC3413DBParser#datatype}.
	 * @param ctx the parse tree
	 */
	void exitDatatype(IIC3413DBParser.DatatypeContext ctx);
	/**
	 * Enter a parse tree produced by {@link IIC3413DBParser#selectStatement}.
	 * @param ctx the parse tree
	 */
	void enterSelectStatement(IIC3413DBParser.SelectStatementContext ctx);
	/**
	 * Exit a parse tree produced by {@link IIC3413DBParser#selectStatement}.
	 * @param ctx the parse tree
	 */
	void exitSelectStatement(IIC3413DBParser.SelectStatementContext ctx);
	/**
	 * Enter a parse tree produced by {@link IIC3413DBParser#columnList}.
	 * @param ctx the parse tree
	 */
	void enterColumnList(IIC3413DBParser.ColumnListContext ctx);
	/**
	 * Exit a parse tree produced by {@link IIC3413DBParser#columnList}.
	 * @param ctx the parse tree
	 */
	void exitColumnList(IIC3413DBParser.ColumnListContext ctx);
	/**
	 * Enter a parse tree produced by {@link IIC3413DBParser#fromStatement}.
	 * @param ctx the parse tree
	 */
	void enterFromStatement(IIC3413DBParser.FromStatementContext ctx);
	/**
	 * Exit a parse tree produced by {@link IIC3413DBParser#fromStatement}.
	 * @param ctx the parse tree
	 */
	void exitFromStatement(IIC3413DBParser.FromStatementContext ctx);
	/**
	 * Enter a parse tree produced by {@link IIC3413DBParser#tableList}.
	 * @param ctx the parse tree
	 */
	void enterTableList(IIC3413DBParser.TableListContext ctx);
	/**
	 * Exit a parse tree produced by {@link IIC3413DBParser#tableList}.
	 * @param ctx the parse tree
	 */
	void exitTableList(IIC3413DBParser.TableListContext ctx);
	/**
	 * Enter a parse tree produced by {@link IIC3413DBParser#table}.
	 * @param ctx the parse tree
	 */
	void enterTable(IIC3413DBParser.TableContext ctx);
	/**
	 * Exit a parse tree produced by {@link IIC3413DBParser#table}.
	 * @param ctx the parse tree
	 */
	void exitTable(IIC3413DBParser.TableContext ctx);
	/**
	 * Enter a parse tree produced by {@link IIC3413DBParser#whereStatement}.
	 * @param ctx the parse tree
	 */
	void enterWhereStatement(IIC3413DBParser.WhereStatementContext ctx);
	/**
	 * Exit a parse tree produced by {@link IIC3413DBParser#whereStatement}.
	 * @param ctx the parse tree
	 */
	void exitWhereStatement(IIC3413DBParser.WhereStatementContext ctx);
	/**
	 * Enter a parse tree produced by {@link IIC3413DBParser#andExpr}.
	 * @param ctx the parse tree
	 */
	void enterAndExpr(IIC3413DBParser.AndExprContext ctx);
	/**
	 * Exit a parse tree produced by {@link IIC3413DBParser#andExpr}.
	 * @param ctx the parse tree
	 */
	void exitAndExpr(IIC3413DBParser.AndExprContext ctx);
	/**
	 * Enter a parse tree produced by {@link IIC3413DBParser#simpleExpr}.
	 * @param ctx the parse tree
	 */
	void enterSimpleExpr(IIC3413DBParser.SimpleExprContext ctx);
	/**
	 * Exit a parse tree produced by {@link IIC3413DBParser#simpleExpr}.
	 * @param ctx the parse tree
	 */
	void exitSimpleExpr(IIC3413DBParser.SimpleExprContext ctx);
	/**
	 * Enter a parse tree produced by {@link IIC3413DBParser#comparisonExpr}.
	 * @param ctx the parse tree
	 */
	void enterComparisonExpr(IIC3413DBParser.ComparisonExprContext ctx);
	/**
	 * Exit a parse tree produced by {@link IIC3413DBParser#comparisonExpr}.
	 * @param ctx the parse tree
	 */
	void exitComparisonExpr(IIC3413DBParser.ComparisonExprContext ctx);
	/**
	 * Enter a parse tree produced by {@link IIC3413DBParser#likeExpr}.
	 * @param ctx the parse tree
	 */
	void enterLikeExpr(IIC3413DBParser.LikeExprContext ctx);
	/**
	 * Exit a parse tree produced by {@link IIC3413DBParser#likeExpr}.
	 * @param ctx the parse tree
	 */
	void exitLikeExpr(IIC3413DBParser.LikeExprContext ctx);
	/**
	 * Enter a parse tree produced by {@link IIC3413DBParser#columnOrConstant}.
	 * @param ctx the parse tree
	 */
	void enterColumnOrConstant(IIC3413DBParser.ColumnOrConstantContext ctx);
	/**
	 * Exit a parse tree produced by {@link IIC3413DBParser#columnOrConstant}.
	 * @param ctx the parse tree
	 */
	void exitColumnOrConstant(IIC3413DBParser.ColumnOrConstantContext ctx);
	/**
	 * Enter a parse tree produced by {@link IIC3413DBParser#column}.
	 * @param ctx the parse tree
	 */
	void enterColumn(IIC3413DBParser.ColumnContext ctx);
	/**
	 * Exit a parse tree produced by {@link IIC3413DBParser#column}.
	 * @param ctx the parse tree
	 */
	void exitColumn(IIC3413DBParser.ColumnContext ctx);
	/**
	 * Enter a parse tree produced by {@link IIC3413DBParser#constant}.
	 * @param ctx the parse tree
	 */
	void enterConstant(IIC3413DBParser.ConstantContext ctx);
	/**
	 * Exit a parse tree produced by {@link IIC3413DBParser#constant}.
	 * @param ctx the parse tree
	 */
	void exitConstant(IIC3413DBParser.ConstantContext ctx);
	/**
	 * Enter a parse tree produced by {@link IIC3413DBParser#identifier}.
	 * @param ctx the parse tree
	 */
	void enterIdentifier(IIC3413DBParser.IdentifierContext ctx);
	/**
	 * Exit a parse tree produced by {@link IIC3413DBParser#identifier}.
	 * @param ctx the parse tree
	 */
	void exitIdentifier(IIC3413DBParser.IdentifierContext ctx);
	/**
	 * Enter a parse tree produced by {@link IIC3413DBParser#limitStatement}.
	 * @param ctx the parse tree
	 */
	void enterLimitStatement(IIC3413DBParser.LimitStatementContext ctx);
	/**
	 * Exit a parse tree produced by {@link IIC3413DBParser#limitStatement}.
	 * @param ctx the parse tree
	 */
	void exitLimitStatement(IIC3413DBParser.LimitStatementContext ctx);
	/**
	 * Enter a parse tree produced by {@link IIC3413DBParser#keyword}.
	 * @param ctx the parse tree
	 */
	void enterKeyword(IIC3413DBParser.KeywordContext ctx);
	/**
	 * Exit a parse tree produced by {@link IIC3413DBParser#keyword}.
	 * @param ctx the parse tree
	 */
	void exitKeyword(IIC3413DBParser.KeywordContext ctx);
}
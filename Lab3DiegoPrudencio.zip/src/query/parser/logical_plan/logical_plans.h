#pragma once

#include "cartesian_product_plan.h"
#include "join_plan.h"
#include "projection_plan.h"
#include "relation_plan.h"
#include "selection_plan.h"
// #include "table_creation.h"
// #include "table_insertion.h"
